rootProject.extra.apply {
    set("androidPlugin", "com.android.tools.build:gradle:4.1.1")
    set("kotlinVersion", "1.4.21")
}

repositories {
    google()
    jcenter()
}
