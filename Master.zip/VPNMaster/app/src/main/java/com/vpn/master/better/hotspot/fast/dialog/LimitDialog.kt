package com.vpn.master.better.hotspot.fast.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.View
import androidx.fragment.app.DialogFragment
import com.vpn.master.better.hotspot.fast.R

class LimitDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return Dialog(requireContext(), R.style.Dialog).apply {
            setContentView(R.layout.dialog_limit)
            findViewById<View>(R.id.tv_limit_dialog_button).setOnClickListener { dismiss() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isCancelable = false
    }

}