package com.vpn.master.better.hotspot.fast.net

import com.google.gson.Gson
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.helper.RequestHelper
import com.vpn.master.better.hotspot.fast.model.Response
import com.vpn.master.better.hotspot.fast.net.EncryptRequestBody.Companion.toEncryptRequestBody
import com.vpn.master.better.hotspot.fast.utils.AppInfo
import com.vpn.master.better.hotspot.fast.utils.FieldManager.mapToReplace
import org.json.JSONObject
import java.lang.reflect.Type

object Request {
    private val request = Manager.createRequest()

    suspend fun <T> get(url: String, params: Map<String, String>?, cls: Class<T>): Response<T> {
        return parseResponse(getInternal(url, params), cls)
    }

    suspend fun <T> get(url: String, params: Map<String, String>?, type: Type): Response<T> {
        return parseResponse(getInternal(url, params), type)
    }

    private suspend fun getInternal(url: String, params: Map<String, String>?): String? {
        return try {
            request.get(url, (params ?: HashMap()).apply {
                this as HashMap
                put("package".mapToReplace(), AppInfo.packageName())
                put("version".mapToReplace(), AppInfo.versionName())
                put("country".mapToReplace(), AppConfig.atCountry())
                put("device".mapToReplace(), AppInfo.deviceId())
            })
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun <T> post(url: String, params: Map<String, String>?, cls: Class<T>): Response<T> {
        return parseResponse(postInternal(url, params), cls)
    }

    private suspend fun postInternal(url: String, params: Map<String, String>?): String? {
        return try {
            val requestParams = params ?: HashMap()
            requestParams.apply {
                this as HashMap
                put("package".mapToReplace(), AppInfo.packageName())
                put("version".mapToReplace(), AppInfo.versionName())
                put("country".mapToReplace(), AppConfig.atCountry())
                put("device".mapToReplace(), AppInfo.deviceId())
            }

            val paramsStr = Gson().toJson(params).toString()
            val encrypt = RequestHelper.encrypt(paramsStr)
            if (encrypt.size >= 2) {
                val encryptRequestBody = encrypt[0].toEncryptRequestBody()
                encryptRequestBody.encryptKey = encrypt[1]
                request.post(url, encryptRequestBody)
            } else {
                request.post(url, paramsStr.toEncryptRequestBody())
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun <T> parseResponse(json: String?, cls: Class<T>): Response<T> {
        if (json.isNullOrEmpty()) return Response(-1, "null", null)
        return try {
            val jsonObj = JSONObject(json)
            Response(
                jsonObj.optInt("err", -3),
                jsonObj.optString("msg", "no response"),
                try {
                    Gson().fromJson(jsonObj.optString("data"), cls)
                } catch (_:Exception) {
                    null
                }
            )
        } catch (_: Exception) {
            Response(-2, "json parse error", null)
        }
    }

    private fun <T> parseResponse(json: String?, type: Type): Response<T> {
        if (json.isNullOrEmpty()) return Response(-1, "null", null)
        return try {
            val jsonObj = JSONObject(json)
            Response(
                jsonObj.optInt("err", -3),
                jsonObj.optString("msg", "no response"),
                try {
                    Gson().fromJson<T>(jsonObj.optString("data"), type)
                } catch (_:Exception) {
                    null
                }
            )
        } catch (_: Exception) {
            Response(-2, "json parse error", null)
        }
    }

}