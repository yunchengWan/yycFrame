package com.vpn.master.better.hotspot.fast.net

import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.*

class SSLHelper {
    companion object {
        val X509TrustManager = object : X509TrustManager {
            override fun checkClientTrusted(
                chain: Array<out X509Certificate>?,
                authType: String?
            ) {

            }

            override fun checkServerTrusted(
                chain: Array<out X509Certificate>?,
                authType: String?
            ) {

            }

            override fun getAcceptedIssuers(): Array<X509Certificate> {
                return emptyArray()
            }

        }

        fun getSSLSocketFactory(): SSLSocketFactory {
            try {
                val sslContext: SSLContext = SSLContext.getInstance("SSL")
                sslContext.init(null, getTrustManager(), SecureRandom())
                return sslContext.socketFactory
            } catch (e: Exception) {
                throw RuntimeException("create sslSocket failed!")
            }
        }

        fun getHostnameVerifier(): HostnameVerifier {
            return HostnameVerifier { _, _ -> true }
        }

        private fun getTrustManager(): Array<TrustManager> {
            return arrayOf(X509TrustManager)
        }
    }
}