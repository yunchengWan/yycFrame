package com.vpn.master.better.hotspot.fast

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.github.shadowsocks.bg.BaseService
import com.vpn.master.better.hotspot.fast.ad.AdHelper
import com.vpn.master.better.hotspot.fast.ad.Interstitial
import com.vpn.master.better.hotspot.fast.dialog.LimitDialog
import com.vpn.master.better.hotspot.fast.dialog.NotifyDialog
import com.vpn.master.better.hotspot.fast.dialog.UpgradeDialog
import com.vpn.master.better.hotspot.fast.helper.ActivityRecord
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.utils.Utils
import com.vpn.master.better.hotspot.fast.viewmodel.HomeViewModel
import com.vpn.master.better.hotspot.fast.widget.ConnectView

class HomeActivity : AppCompatActivity() {

    private val serverResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                updateServer()
                if (viewModel.stateLiveData.value!!.canStop) {
                    isReConnect = true
                    stopConnect()
                }
            }
        }
    private val permissionResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                startConnect()
            } else {
                Toast.makeText(this, R.string.vpn_permission_denied, Toast.LENGTH_SHORT).show()
            }
        }

    private val viewModel = ViewModelProvider.AndroidViewModelFactory
        .getInstance(MasterApp.instance)
        .create(HomeViewModel::class.java)

    private lateinit var connectView: ConnectView
    private lateinit var connectStateTv: TextView
    private lateinit var connectBtnTv: TextView
    private lateinit var locationView: View
    private lateinit var serverIconIv: ImageView
    private lateinit var serverNameTv: TextView

    private var isReConnect = false

    private var connectAd: Interstitial? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        initView()
        initData()

        if (AppConfig.showNotify) {
            showNotifyDialog()
        }
    }

    private fun initView() {
        connectView = findViewById(R.id.connect_view_home)
        connectStateTv = findViewById(R.id.tv_home_connect_state)
        connectBtnTv = findViewById(R.id.tv_home_connect)
        locationView = findViewById(R.id.ll_home_location)
        serverIconIv = findViewById(R.id.iv_home_server_icon)
        serverNameTv = findViewById(R.id.tv_home_server_name)

        updateServer()
        connectView.disConnected()

    }

    private fun initData() {
        viewModel.connectService(this)

        viewModel.stateLiveData.observeForever { state ->
            when (state) {
                BaseService.State.Idle -> showDisconnect()
                BaseService.State.Connected -> showConnected()
                BaseService.State.Stopped -> {
                    if (isReConnect) {
                        startConnect()
                        isReConnect = false
                    } else {
                        showDisconnect()
                    }
                }
                else -> {
                }
            }
        }
        viewModel.errorCodeLiveDate.observe(this, Observer<Int> { errorCode ->
            when (errorCode) {
                HomeViewModel.ERROR_CODE_NO_SERVER -> {
                    Toast.makeText(this, R.string.connect_error_tip, Toast.LENGTH_SHORT).show()
                    showDisconnect(false)
                    showConnectAd()
                }
                HomeViewModel.ERROR_CODE_PING_FAILED -> {
                    Toast.makeText(this, R.string.connect_error_tip, Toast.LENGTH_SHORT).show()
                    showDisconnect(false)
                    showConnectAd()
                }
                HomeViewModel.ERROR_CODE_NO_NETWORK -> {
                    Toast.makeText(this, R.string.no_network, Toast.LENGTH_SHORT).show()
                    showDisconnect()
                }
                HomeViewModel.ERROR_CODE_LIMIT -> {
                    showLimitDialog()
                    showDisconnect()
                }
                HomeViewModel.ERROR_CODE_NEED_UPDATE -> {
                    showUpgradeDialog()
                    showDisconnect()
                }
            }
        })
    }

    private fun updateServer() {
        if (AppConfig.selectServer == null) {
            serverIconIv.setImageResource(R.drawable.ic_location_auto)
            serverNameTv.text = getString(R.string.server_auto)
        } else {
            with(AppConfig.selectServer) {
                if (this == null) {
                    return
                }
                serverIconIv.setImageResource(Utils.getCountryIcon(country_name))
                serverNameTv.text = "$country_name - ${city[0].city_name}"
            }
        }
    }

    private fun startConnect() {
        viewModel.connectVpn()
        showConnecting()
    }

    private fun stopConnect() {
        showDisconnecting()
        connectView.postDelayed({ viewModel.disconnectVpn() }, 1000L)
    }

    private fun showConnecting() {
        ActivityRecord.isConnecting = true
        connectView.connecting()
        connectStateTv.text = getString(R.string.connecting)
        connectBtnTv.text = getString(R.string.connecting)
        changeButtonEnable(false)
    }

    private fun showDisconnecting() {
        connectView.connecting()
        connectStateTv.text = getString(R.string.disconnecting)
        connectBtnTv.text = getString(R.string.disconnecting)
        changeButtonEnable(false)
    }

    private fun showConnected() {
        ActivityRecord.isConnecting = false
        connectView.connected()
        connectStateTv.text = getString(R.string.connected)
        connectBtnTv.text = getString(R.string.disconnect)

        showConnectAd()
    }

    private fun showDisconnect(enableButton: Boolean = true) {
        ActivityRecord.isConnecting = false
        connectView.disConnected()
        connectStateTv.text = getString(R.string.disconnected)
        connectBtnTv.text = getString(R.string.connect)
        if (enableButton) changeButtonEnable(true)
    }

    private fun changeButtonEnable(enable: Boolean) {
        connectBtnTv.isEnabled = enable
        locationView.isEnabled = enable
        connectView.isEnabled = enable
    }

    private fun showConnectAd() {
        if (!ActivityRecord.inBackground && ActivityRecord.currentActivityIsHome) {
            connectAd = AdHelper.getConnectAd()
            connectAd?.let {
                ActivityRecord.isShowingConnectAd = true
                it.closeListener {
                    changeButtonEnable(true)
                    ActivityRecord.isShowingConnectAd = false
                }
                it.show()
            } ?: changeButtonEnable(true)
        } else {
//            Log.d("CONNECT_AD", "app in background or not home, not display ad")
            changeButtonEnable(true)
        }
    }

    private fun checkPermission() {
        val intent = VpnService.prepare(this)
        if (intent == null) {
            startConnect()
        } else {
            permissionResult.launch(intent)
        }
    }

    private fun showUpgradeDialog() {
        UpgradeDialog().show(supportFragmentManager, "UpgradeDialog")
        AppConfig.upgradeIsShow = true
    }

    private fun showNotifyDialog() {
        NotifyDialog().show(supportFragmentManager, "NotifyDialog")
    }

    private fun showLimitDialog() {
        LimitDialog().show(supportFragmentManager, "LimitDialog")
    }

    fun onClick(view: View) {
        when (view.id) {
            R.id.connect_view_home, R.id.tv_home_connect -> {
                if (AppConfig.showUpgrade) {
                    showUpgradeDialog()
                } else {
                    if (viewModel.stateLiveData.value!!.canStop) stopConnect()
                    else checkPermission()
                }
            }

            R.id.ll_home_location -> serverResult.launch(
                Intent(
                    this,
                    ChooseServerActivity::class.java
                )
            )
        }
    }

    override fun onBackPressed() {
        moveTaskToBack(true)
    }

}