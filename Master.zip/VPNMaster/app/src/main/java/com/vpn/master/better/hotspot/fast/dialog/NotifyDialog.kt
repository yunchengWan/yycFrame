package com.vpn.master.better.hotspot.fast.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.vpn.master.better.hotspot.fast.R
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.utils.Utils

class NotifyDialog : DialogFragment() {
    private lateinit var titleTv: TextView
    private lateinit var contentTv: TextView
    private lateinit var buttonTv: TextView

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return Dialog(requireContext(), R.style.Dialog).apply {
            setContentView(R.layout.dialog_notify)
            setCanceledOnTouchOutside(false)
            initView(this)
        }
    }

    private fun initView(dialog: Dialog) {
        titleTv = dialog.findViewById(R.id.tv_notify_dialog_title)
        contentTv = dialog.findViewById(R.id.tv_notify_dialog_content)
        buttonTv = dialog.findViewById(R.id.tv_notify_dialog_button)

        AppConfig.notifyInfo?.let { notifyInfo ->
            titleTv.text = notifyInfo.title
            contentTv.text = notifyInfo.info
            buttonTv.apply {
                setOnClickListener {
                    Utils.launchUrl(requireContext(), notifyInfo.url)
                    dismiss()
                }
                text = notifyInfo.text
            }
        }
        dialog.findViewById<View>(R.id.iv_notify_close).setOnClickListener {
            dismiss()
        }

    }

}