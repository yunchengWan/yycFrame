package com.vpn.master.better.hotspot.fast.model

data class Response<T>(
    var code: Int,
    var msg: String? = null,
    var data: T? = null,
)