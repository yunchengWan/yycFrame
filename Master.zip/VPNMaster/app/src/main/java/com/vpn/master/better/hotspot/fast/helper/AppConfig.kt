package com.vpn.master.better.hotspot.fast.helper

import com.google.gson.Gson
import com.vpn.master.better.hotspot.fast.model.*
import com.vpn.master.better.hotspot.fast.net.HttpUrl
import com.vpn.master.better.hotspot.fast.net.Request
import com.vpn.master.better.hotspot.fast.utils.SpUtils
import com.vpn.master.better.hotspot.fast.utils.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.*

object AppConfig {

    var serverInfo: ServerInfo? = null
    var selectServer: Server? = null
    val serverCount: Int
        get() = serverInfo?.free_server?.size ?: 0

    var atCountry: String?
        get() = SpUtils.getString("country")
        set(value) = SpUtils.putString("country", value)

    var upgradeInfo: UpgradeInfo? = null
    val showUpgrade: Boolean
        get() = upgradeInfo?.let { (it.suggest == 2 && !upgradeIsShow) || it.suggest == 3 } ?: false
    var upgradeIsShow = false

    var notifyInfo: NotifyInfo? = null
    val showNotify: Boolean
        get() = notifyInfo != null

    var adConfig: AdConfigInfo? = null
    val totalShowLimit: Int
        get() = adConfig?.showLimit ?: 0
    val totalClickLimit: Int
        get() = adConfig?.clickLimit ?: 0
    val connectShowLimit: Int
        get() = adConfig?.connectAd?.showLimit ?: 0
    val connectClickLimit: Int
        get() = adConfig?.connectAd?.clickLimit ?: 0
    val expireTime: Int
        get() = adConfig?.expire ?: 3000

    private val randomUuid = UUID.randomUUID().toString()

    fun atCountry(): String {
        return if (atCountry.isNullOrEmpty()) randomUuid
        else atCountry!!
    }

    fun initAdmin() {
        adConfig = getAdConfigFromLocal()
        sortAdsPriority()

        GlobalScope.launch(Dispatchers.IO) {
            initServer()?.join()

            launch {
                val result = getNotify()
                if (result.code == 0) {
                    notifyInfo = result.data
                }
            }

            initUpdateInfo()?.join()

            launch {
                val result = getIpInfo()
                if (result.code == 0) {
                    result.data?.let {
                        if (!it.country_code.isNullOrEmpty()) {
                            atCountry = it.country_code
                        }
                    }
                }
            }

            launch {
                val result = getAdConfig()
                if (result.code == 0) {
                    result.data?.let {
                        it.ads_ret?.let { list ->
                            if (list.isNotEmpty()) {
                                adConfig = list[0]
                                SpUtils.putString("ad_config", Gson().toJson(adConfig))
                                sortAdsPriority()
                            }
                        }
                    }
                }
            }

        }
    }

    fun initServer(): Job? {
        if (serverInfo != null) {
            return null
        }
        return GlobalScope.launch(Dispatchers.IO) {
            val result = getServer()
            if (result.code == 0) {
                serverInfo = result.data
            }
        }
    }

    fun initUpdateInfo(): Job? {
        if (upgradeInfo != null) return null
        return GlobalScope.launch(Dispatchers.IO) {
            val result = getUpgrade()
            if (result.code == 0) {
                upgradeInfo = result.data
            }
        }
    }

    private suspend fun getServer(): Response<ServerInfo> {
        return Request.get(HttpUrl.SERVER_LIST, null, ServerInfo::class.java)
    }

    private suspend fun getNotify(): Response<NotifyInfo> {
        return Request.get(HttpUrl.NOTIFY_CONFIG, null, NotifyInfo::class.java)
    }

    private suspend fun getUpgrade(): Response<UpgradeInfo> {
        return Request.get(HttpUrl.UPGRADE, null, UpgradeInfo::class.java)
    }

    private suspend fun getIpInfo(): Response<IpInfo> {
        return Request.post(HttpUrl.IP_INFO, null, IpInfo::class.java)
    }

    private suspend fun getAdConfig(): Response<AdConfigWrapper> {
        return Request.get(HttpUrl.AD_CONFIG, null, AdConfigWrapper::class.java)
    }

    private fun getAdConfigFromLocal(): AdConfigInfo {
        var configStr = SpUtils.getString("ad_config")
        if (configStr.isNullOrEmpty()) configStr = Utils.readAssert("AdConfig.json")
        return Gson().fromJson(configStr, AdConfigInfo::class.java)
    }

    private fun sortAdsPriority() {
        adConfig?.let { configInfo ->
            configInfo.connectAd.ads = configInfo.connectAd.ads.sortedBy { -it.priority }
        }
    }

}