package com.vpn.master.better.hotspot.fast.net

object HttpUrl {

    const val SERVER_LIST = "tt/v1/tes/ssv/"

    const val GET_ACCOUNTS = "tt/v1/tes/cm/"

    const val GET_ACCOUNT_BY_COUNTRY = "tt/v1/tes/co/"

    const val NOTIFY_CONFIG = "tt/v1/ra/tz/"

    const val UPGRADE = "tt/v1/ra/vvc/"

    const val AD_CONFIG = "tt/v1/ra/das/"

    const val IP_INFO = "tt/v1/ra/from/"

}