package com.vpn.master.better.hotspot.fast.utils

import android.app.Activity
import com.vpn.master.better.hotspot.fast.MasterApp

class SpUtils {
    companion object {
        private val sp =
            MasterApp.instance.getSharedPreferences("master_data", Activity.MODE_PRIVATE)

        fun putString(key: String, value: String?) {
            if (value.isNullOrEmpty()) return
            sp.edit().putString(key, value).apply()
        }

        fun getString(key: String): String? {
            return sp.getString(key, null)
        }

        fun putInt(key: String, value: Int) {
            sp.edit().putInt(key, value).apply()
        }

        fun getInt(key: String): Int {
            return sp.getInt(key, 0)
        }

    }
}