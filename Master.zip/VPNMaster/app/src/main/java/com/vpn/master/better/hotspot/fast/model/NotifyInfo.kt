package com.vpn.master.better.hotspot.fast.model

//{"title":"TestNotify","info":"This is test notify","text":"Google","url":"http://www.google.com","version_code":1}

data class NotifyInfo(
    var title: String?,
    var info: String?,
    var text: String?,
    var url: String?,
    var version_code: Int?
)