package com.vpn.master.better.hotspot.fast.utils

import org.json.JSONArray
import org.json.JSONObject

object FieldManager {
    private const val fieldInfo =
        """{
        "err":"nGJFrCnJh",
        "msg":"VJD",
        "data":"gkYafaTp",
        "package":"VtuOgvNN",
        "country":"nvFwybQzpN",
        "version":"XFx",
        "device":"NrkaIoE",
        "conn_mode":"elzJQvm",
        "conn_dest":"mtB",
        "suggest":"XPnfpIT",
        "title":"utokBo",
        "info":"FlmbuD",
        "version_name":"tEiwCWEIDi",
        "version_code":"YlFPlEwRg",
        "city":"XUqFXT",
        "city_name":"TPnIV",
        "city_id":"id",
        "country_name":"opE",
        "country_code":"zTzZ",
        "settings_name":"mPiPylJE",
        "open_name":"pTel",
        "socks_name":"xOktCvXS",
        "text":"nIpoSZdqwu",
        "url":"PqjBlTdQ",
        "encrypt":"YWjktNObFC",
        "pwd":"tzyI",
        "ip":"ZGgxAGrB",
        "port":"OfqQFyd",
        "ads_ret":"DkiELMhuEA",
        "free_server":"oJSLy",
        "pro_server":"AKh"
    }"""

    private val replaceArray: ArrayList<String> = ArrayList(31)
    private val originArray: ArrayList<String> = ArrayList(31)

    fun setup() {
        try {
            val json = JSONObject(fieldInfo)
            json.keys().forEach {
                val value = json.optString(it)
                replaceArray.add(value)
                originArray.add(it)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun String.mapToReplace(): String {
        val index = originArray.indexOf(this)
        return if (index >= 0) replaceArray[index] else this
    }

    fun String.mapToOrigin(): String {
        val index = replaceArray.indexOf(this)
        return if (index >= 0) originArray[index] else this
    }

    fun replaceJsonField(jsonStr: String): String {
        var result = jsonStr
        replaceArray.forEachIndexed { index, str->
            result = result.replace("\"$str\"", "\"${originArray[index]}\"")
        }
        return result
    }

}


