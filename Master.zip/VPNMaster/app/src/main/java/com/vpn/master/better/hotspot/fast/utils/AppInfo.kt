package com.vpn.master.better.hotspot.fast.utils

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.vpn.master.better.hotspot.fast.BuildConfig
import com.vpn.master.better.hotspot.fast.MasterApp
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class AppInfo {
    companion object {
        fun packageName(): String {
            return MasterApp.instance.packageName
        }

        fun versionName(): String {
            return BuildConfig.VERSION_NAME
        }

        fun deviceId(): String {
            val androidId = Settings.System.getString(
                MasterApp.instance.contentResolver,
                Settings.Secure.ANDROID_ID
            )
            if (!androidId.isNullOrEmpty()) {
                return androidId
            }
            val manager = MasterApp.instance.getSystemService(Context.TELEPHONY_SERVICE)
            manager as TelephonyManager
            return manager.deviceId
        }

        fun androidVersion(): String {
            return Build.VERSION.RELEASE
        }

        fun model(): String {
            return Build.MODEL
        }

        fun buildID(): String {
            return "Build/${Build.ID}"
        }

        suspend fun advertsId(): String = suspendCancellableCoroutine {
            try {
                it.resume(AdvertisingIdClient.getAdvertisingIdInfo(MasterApp.instance).id)
            } catch (_: Exception) {
                it.resume("")
            }
        }

        suspend fun adLimitTracking(): Boolean = suspendCancellableCoroutine {
            try {
                it.resume(AdvertisingIdClient.getAdvertisingIdInfo(MasterApp.instance).isLimitAdTrackingEnabled)
            } catch (_: Exception) {
                it.resume(false)
            }
        }
    }
}