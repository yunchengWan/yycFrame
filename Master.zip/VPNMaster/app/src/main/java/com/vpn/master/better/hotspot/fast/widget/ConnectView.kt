package com.vpn.master.better.hotspot.fast.widget

import android.content.Context
import android.util.AttributeSet
import android.view.animation.Animation
import android.widget.FrameLayout
import android.widget.ImageView
import com.airbnb.lottie.LottieAnimationView
import com.vpn.master.better.hotspot.fast.R
import com.vpn.master.better.hotspot.fast.utils.dp

class ConnectView : FrameLayout {

    private lateinit var imageView: ImageView
    private var lottieView: LottieAnimationView? = null

    constructor(context: Context) : super(context)

    constructor(context: Context, attributes: AttributeSet?) : super(context, attributes)

    constructor(context: Context, attributes: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attributes,
        defStyleAttr
    )

    fun connecting() {
        removeAllViews()
        showConnectedOrDisConnected(R.drawable.ic_disconnected)
        lottieView = LottieAnimationView(context)
        addView(lottieView)
        lottieView?.apply {
            layoutParams.width = 260.dp
            layoutParams.height = 260.dp
            setAnimation("connecting.json")
            repeatCount = Animation.INFINITE
        }
        lottieView!!.playAnimation()
    }

    fun disConnected() {
        showConnectedOrDisConnected(R.drawable.ic_disconnected)
    }

    fun connected() {
        showConnectedOrDisConnected(R.drawable.ic_connected)
    }

    private fun showConnectedOrDisConnected(resourceId: Int) {
        removeAllViews()
        if (!this::imageView.isInitialized) {
            imageView = ImageView(context)
        }
        addView(imageView)
        imageView.apply {
            setImageResource(resourceId)
            (layoutParams as LayoutParams).setMargins(30.dp, 30.dp, 30.dp, 30.dp)
            layoutParams.width = 200.dp
            layoutParams.height = 200.dp
        }
    }

}