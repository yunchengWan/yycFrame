package com.vpn.master.better.hotspot.fast.net

import android.util.Log
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.scalars.ScalarsConverterFactory

object Manager {

    private fun retrofit(config: RetrofitConfig): Retrofit {
        return Retrofit.Builder()
            .baseUrl(config.baseUrl)
            .client(config.client())
            .addConverterFactory(ScalarsConverterFactory.create())
            .build()
    }

    fun createRequest(): Server {
        return retrofit(Normal()).create(Server::class.java)
    }

    fun createHeartRequest(): Server {
        return retrofit(Heart()).create(Server::class.java)
    }
}

interface RetrofitConfig {
    val baseUrl: String

    fun client(): OkHttpClient

    fun logInterceptor(): Interceptor {
        return HttpLoggingInterceptor(
            object : HttpLoggingInterceptor.Logger {
                override fun log(message: String) {
//                    Log.d("MasterRequest", message)
                }
            }
        ).apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
    }

}

class Normal : RetrofitConfig {

//    override val baseUrl: String = Config.TEST_BASE_URL
    override val baseUrl: String = Config.BASE_URL

    override fun client(): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(logInterceptor())
            .addInterceptor(RequestInterceptor())
            .build()
    }

}

class Heart : RetrofitConfig {
    override val baseUrl: String = "https://a/"

    override fun client(): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(logInterceptor())
            .addInterceptor(LogHeaderInterceptor())
            .hostnameVerifier(SSLHelper.getHostnameVerifier())
            .sslSocketFactory(SSLHelper.getSSLSocketFactory(), SSLHelper.X509TrustManager)
            .build()
    }
}