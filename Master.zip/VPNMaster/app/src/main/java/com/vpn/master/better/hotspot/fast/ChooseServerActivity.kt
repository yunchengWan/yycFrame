package com.vpn.master.better.hotspot.fast

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.vpn.master.better.hotspot.fast.adapter.ServerAdapter
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class ChooseServerActivity : AppCompatActivity() {
    private lateinit var adapter: ServerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_server)

        adapter = ServerAdapter().apply {
            setListener {
                this@ChooseServerActivity.setResult(Activity.RESULT_OK)
                this@ChooseServerActivity.finish()
            }
        }
        findViewById<RecyclerView>(R.id.rv_choose_server).apply {
            adapter = this@ChooseServerActivity.adapter
            layoutManager = LinearLayoutManager(this@ChooseServerActivity)
        }

        AppConfig.initServer()?.let {
            GlobalScope.launch(Dispatchers.Main) {
                if (it.isActive) it.join()
                adapter.notifyDataSetChanged()
            }
        }
    }

    fun onClick(view: View) {
        when (view.id) {
            R.id.iv_choose_server_back -> finish()
        }
    }

}