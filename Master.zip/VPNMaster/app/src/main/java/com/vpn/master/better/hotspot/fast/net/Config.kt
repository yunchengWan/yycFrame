package com.vpn.master.better.hotspot.fast.net

class Config {
    companion object {
        const val BASE_URL = "https://gmprod.vpn-master.im/"
        const val TEST_BASE_URL = "https://gmtest.vpn-master.im/"
    }
}