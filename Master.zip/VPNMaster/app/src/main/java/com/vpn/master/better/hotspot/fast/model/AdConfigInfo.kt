package com.vpn.master.better.hotspot.fast.model

data class AdConfigWrapper(
    var ads_ret: List<AdConfigInfo>?
)

data class AdConfigInfo(
    var showLimit: Int = 50,
    var clickLimit: Int = 20,
    var expire: Int = 50 * 60 * 1000,
    var connectAd: Ad
)

data class Ad(
    var showLimit: Int = 10,
    var clickLimit: Int = 3,
    var ads: List<Config>
)

data class Config(
    val priority: Int,
    var timeout: Int = 10 * 1000,
    var adId: String
)