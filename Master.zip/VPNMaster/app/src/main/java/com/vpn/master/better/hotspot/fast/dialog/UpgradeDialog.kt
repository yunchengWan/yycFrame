package com.vpn.master.better.hotspot.fast.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.vpn.master.better.hotspot.fast.R
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.utils.Utils

class UpgradeDialog : DialogFragment() {

    private lateinit var titleTv: TextView
    private lateinit var contentTv: TextView
    private lateinit var buttonTv: TextView
    private lateinit var closeIv: ImageView

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return Dialog(requireContext(), R.style.Dialog).apply {
            setContentView(R.layout.dialog_upgrade)
            initView(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isCancelable = false
    }

    private fun initView(dialog: Dialog) {
        titleTv = dialog.findViewById(R.id.tv_upgrade_title)
        contentTv = dialog.findViewById(R.id.tv_upgrade_content)
        buttonTv = dialog.findViewById(R.id.tv_upgrade_button)
        closeIv = dialog.findViewById(R.id.iv_upgrade_close)

        val upgradeInfo = AppConfig.upgradeInfo
        upgradeInfo?.let {
            titleTv.text = it.title
            contentTv.text = it.info
            closeIv.visibility = if (it.suggest == 3) View.GONE else View.VISIBLE
        }
        closeIv.setOnClickListener { dismiss() }
        buttonTv.setOnClickListener {
            Utils.launchGooglePlay(requireContext())
            dismiss()
        }
    }

}