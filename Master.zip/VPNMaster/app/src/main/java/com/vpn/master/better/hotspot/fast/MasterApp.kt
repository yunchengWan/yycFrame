package com.vpn.master.better.hotspot.fast

import android.app.Application
import android.content.res.Configuration
import com.github.shadowsocks.Core
import com.google.android.gms.ads.MobileAds
import com.vpn.master.better.hotspot.fast.ad.AdHelper
import com.vpn.master.better.hotspot.fast.helper.ActivityRecord
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.utils.FieldManager

class MasterApp : Application() {

    companion object {
        lateinit var instance: Application
    }

    override fun onCreate() {
        super.onCreate()

        instance = this

        ActivityRecord.register(this)
        Core.init(this, HomeActivity::class)
        MobileAds.initialize(applicationContext)
        FieldManager.setup()
        AppConfig.initAdmin()

        AdHelper.preLoadAd()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Core.updateNotificationChannels()
    }

}