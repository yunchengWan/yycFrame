package com.vpn.master.better.hotspot.fast.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.vpn.master.better.hotspot.fast.R
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.utils.Utils

class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    val icon: ImageView = itemView.findViewById(R.id.iv_icon_server)
    val country: TextView = itemView.findViewById(R.id.tv_name_server)

}

class ServerAdapter : RecyclerView.Adapter<ViewHolder>() {

    var clickListener: () -> Unit = {}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_server, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return AppConfig.serverCount + 1
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (position == 0) {
            holder.icon.setImageResource(R.drawable.ic_location_auto)
            holder.country.text = "AUTO"
            holder.itemView.setOnClickListener {
                AppConfig.selectServer = null
                clickListener()
            }
        } else {
            with(AppConfig.serverInfo!!.free_server[position - 1]) {
                holder.icon.setImageResource(Utils.getCountryIcon(country_name))
                holder.country.text = "$country_name - ${city[0].city_name}"
                holder.itemView.setOnClickListener {
                    AppConfig.selectServer = this
                    clickListener()
                }
            }
        }
    }

    fun setListener(listener: () -> Unit) {
        clickListener = listener
    }

}