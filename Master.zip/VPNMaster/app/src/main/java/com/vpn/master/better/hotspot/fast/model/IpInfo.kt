package com.vpn.master.better.hotspot.fast.model

data class IpInfo(
    var country_code: String?,
    var country_name: String?,
    var ip: String?
)