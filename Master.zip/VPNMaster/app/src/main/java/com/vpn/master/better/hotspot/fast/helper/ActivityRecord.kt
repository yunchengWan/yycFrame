package com.vpn.master.better.hotspot.fast.helper

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle
import com.vpn.master.better.hotspot.fast.HomeActivity
import com.vpn.master.better.hotspot.fast.LoadingActivity
import com.vpn.master.better.hotspot.fast.ad.AdHelper

object ActivityRecord {

    var homeLaunched = false
    var inBackground = false
    var currentActivityIsHome = false
    private var activityCount = 0

    var isConnecting = false
    var isShowingConnectAd = false

    fun register(app: Application) {

        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityPaused(activity: Activity) {

            }

            override fun onActivityStarted(activity: Activity) {
                inBackground = false
                if (activityCount == 0
                    && activity.componentName.className != LoadingActivity::class.java.name
                    && !isConnecting
                    && !isShowingConnectAd
                ) {
                    activity.startActivity(Intent(activity, LoadingActivity::class.java))
                }
                if (activity.componentName.className == HomeActivity::class.java.name) {
                    currentActivityIsHome = true
                }
                activityCount++
            }

            override fun onActivityDestroyed(activity: Activity) {

            }

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {

            }

            override fun onActivityStopped(activity: Activity) {
                activityCount--
                if (activityCount == 0) {
                    inBackground = true
                }
                if (activity.componentName.className == HomeActivity::class.java.name) {
                    currentActivityIsHome = false
                }
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                if (activity.componentName.className == HomeActivity::class.java.name) {
                    homeLaunched = true
                }
            }

            override fun onActivityResumed(activity: Activity) {
                if (activity.componentName.className == HomeActivity::class.java.name) {
                    AdHelper.preLoadAd()
                }
            }
        })
    }

}