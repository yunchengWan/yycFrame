package com.vpn.master.better.hotspot.fast.helper

import android.util.Base64
import kotlin.random.Random

class RequestHelper {
    companion object {

        private const val charCollection = "0123456789qwertyuiopasdfghjklzxcvbnm"

        fun encrypt(origin: String): Array<String> {
            val base64 = Base64.encodeToString(origin.toByteArray(), Base64.NO_WRAP)
            val pass = base64.substring(1, 4) + randomString(9)
            val result = base64.removeRange(1, 4)
            return arrayOf(result, pass)
        }

        fun decrypt(origin: String, pass: String): String {
            if (origin.isEmpty() || pass.isEmpty()) {
                return origin
            }
            val sb = StringBuilder()
            sb.append(origin.substring(0, 1))
            sb.append(pass.subSequence(0, 3))
            sb.append(origin.substring(1, origin.length))
            java.util.Random()
            return String(Base64.decode(sb.toString().toByteArray(), Base64.NO_WRAP))
        }

        fun randomString(length: Int): String {
            val sb = StringBuilder()
            repeat(length) {
                sb.append(
                    charCollection[
                            Random(it).nextInt(0, charCollection.length) % charCollection.length
                    ]
                )
            }
            return sb.toString()
        }
    }
}