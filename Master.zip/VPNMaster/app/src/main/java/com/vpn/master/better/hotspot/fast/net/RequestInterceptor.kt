package com.vpn.master.better.hotspot.fast.net

import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.helper.RequestHelper
import com.vpn.master.better.hotspot.fast.utils.FieldManager
import com.vpn.master.better.hotspot.fast.utils.FieldManager.mapToReplace
import okhttp3.Interceptor
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody

class RequestInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val originRequest = chain.request()
        val requestBuilder = originRequest.newBuilder()
        if (originRequest.method == "POST") {
            val requestBody = originRequest.body as EncryptRequestBody
            if (!requestBody.encryptKey.isNullOrEmpty()) {
                requestBuilder.addHeader("p", requestBody.encryptKey!!)
            }
        }

        val originResponse = chain.proceed(requestBuilder.build())
        val pass = originResponse.headers["p"] ?: ""
        val bodyStr = originResponse.body?.string() ?: ""
        val country = originResponse.headers["country".mapToReplace()] ?: ""
        if (country.isNotEmpty()) {
            AppConfig.atCountry = country
        }

        return originResponse.newBuilder()
            .body(FieldManager.replaceJsonField(RequestHelper.decrypt(bodyStr, pass)).toResponseBody())
            .build()
    }
}