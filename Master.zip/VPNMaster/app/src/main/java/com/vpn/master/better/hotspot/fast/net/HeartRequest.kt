package com.vpn.master.better.hotspot.fast.net

import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import okhttp3.RequestBody.Companion.toRequestBody

object HeartRequest {
    private val request = Manager.createHeartRequest()

    suspend fun getByFullUrl(url: String, params: Map<String, String>?): String? {
        return request.getByFullUrl(url, params ?: HashMap())
    }

    suspend fun postByFullUrl(url: String, params: JsonElement?): String? {
        return request.postByFullUrl(url, params?.let { params.toString().toRequestBody() } ?: "".toRequestBody())
    }
}