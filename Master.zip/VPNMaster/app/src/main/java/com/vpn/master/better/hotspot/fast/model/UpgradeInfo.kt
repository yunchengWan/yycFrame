package com.vpn.master.better.hotspot.fast.model

data class UpgradeInfo(
    val suggest: Int,
    var title: String,
    var info: String,
    var version_name: String,
    var version_code: Int
)