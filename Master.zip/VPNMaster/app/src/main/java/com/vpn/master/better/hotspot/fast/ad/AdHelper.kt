package com.vpn.master.better.hotspot.fast.ad

import android.util.Log
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.utils.SpUtils
import com.vpn.master.better.hotspot.fast.utils.withTimeoutNotCancel
import kotlinx.coroutines.*
import java.util.*

object AdHelper {

    private val connectAds = LinkedList<Interstitial>()
    private val adRequest = AdMobRequest()

    private var requestingConnectAd = false
    private var connectAdJob: Job? = null

    private val totalShow: Int
        get() = connectShow
    private val totalClick: Int
        get() = connectClick
    private var connectShow: Int
        set(value) = SpUtils.putInt("connect_ad_show_count", value)
        get() = SpUtils.getInt("connect_ad_show_count")
    private var connectClick: Int
        set(value) = SpUtils.putInt("connect_ad_click_count", value)
        get() = SpUtils.getInt("connect_ad_click_count")

    init {
        val date = SpUtils.getString("master_date")
        if (date.isNullOrEmpty()) {
            val year = Calendar.getInstance().get(Calendar.YEAR)
            val month = Calendar.getInstance().get(Calendar.MONTH)
            val day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
            SpUtils.putString("master_date", "$year-$month-$day")
        } else {
            val array = date.split("-")
            val year = array[0].toInt()
            val month = array[1].toInt()
            val day = array[2].toInt()

            val nowYear = Calendar.getInstance().get(Calendar.YEAR)
            val nowMonth = Calendar.getInstance().get(Calendar.MONTH)
            val nowDay = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
            if (year != nowYear || month != nowMonth || day != nowDay) {
                connectShow = 0
                connectClick = 0
                SpUtils.putString("master_date", "$nowYear-$nowMonth-$nowDay")
            }
        }
    }

    fun getConnectAd(): Interstitial? {
//        Log.d("CONNECT_AD", "get connectAd, list size:${connectAds.size}")
        if (!assertConnectAdCount()) {
//            Log.d("CONNECT_AD", "reached connectAd Limit")
            return null
        }
        if (connectAds.isEmpty()) {
//            Log.d("CONNECT_AD", "connectAd list is null")
            return null
        }
        if (!hasAvailableConnectAd()) {
//            Log.d("CONNECT_AD", "all cached ad expired")
            requestConnectAd()
            return null
        }
        val ad = connectAds.removeLast()
        ad.clickListener { connectClick++ }
        ad.showListener { connectShow++ }
//        Log.d("CONNECT_AD", "get connectAd, ad: $ad, after list size: ${connectAds.size}")
        GlobalScope.launch(Dispatchers.IO) {
            delay(500)
            requestConnectAd()
        }
        return ad
    }

    fun requestConnectAd(): Job? {
//        Log.d("CONNECT_AD", "request connectAd")
        if (!assertConnectAdCount()) {
//            Log.d("CONNECT_AD", "reached connectAd Limit")
            return connectAdJob
        }
        if (requestingConnectAd || hasAvailableConnectAd()) {
//            Log.d(
//                "CONNECT_AD",
//                "connectAd is requesting or list is not null, list size:${connectAds.size}"
//            )
            return connectAdJob
        }
        requestingConnectAd = true

        connectAdJob = GlobalScope.launch(Dispatchers.Main) {

            val connectAdConfig = AppConfig.adConfig?.connectAd

            connectAdConfig?.let { config ->
                coroutineScope {
                    for (index in config.ads.indices) {
                        val timeout = config.ads[index].timeout
                        val result = withTimeoutNotCancel(Dispatchers.Main, timeout.toLong() * 1000) {
                            val id = config.ads[index].adId
                            val priority = config.ads[index].priority
//                            Log.d(
//                                "CONNECT_AD",
//                                "start request connectAd, priority = $priority, id = $id"
//                            )
                            val ad = adRequest.requestInterstitial(id)
//                            Log.d(
//                                "CONNECT_AD",
//                                "end request connectAd, priority = ${priority}, result:${ad.hashCode()}"
//                            )
                            if (ad != null) {
                                ad.priority = priority
                                addAdByPriority(connectAds, ad)
                                1
                            } else {
                                null
                            }
                        }
                        if (result != null) {
                            break
                        }
                    }
                }
            }
//            Log.d("CONNECT_AD", "end request connectAd")

            requestingConnectAd = false
        }
        return connectAdJob
    }

    private fun <T : Ad> addAdByPriority(list: LinkedList<T>, ad: T) {
        if (list.isEmpty()) {
//            Log.d("CONNECT_AD", "add ${ad.hashCode()}(priority=${ad.priority}) to first")
            list.addFirst(ad)
        } else {
            var insertIndex = -1
            for (index in list.indices) {
                if (list[index].priority >= ad.priority) {
                    insertIndex = index
                    break
                }
            }
            if (insertIndex == -1) {
//                Log.d("CONNECT_AD", "add ${ad.hashCode()}(priority=${ad.priority}) to last")
                list.addLast(ad)
            } else {
//                Log.d("CONNECT_AD", "add ${ad.hashCode()}(priority=${ad.priority}) to $insertIndex")
                list.add(insertIndex, ad)
            }
        }
    }

    private fun hasAvailableConnectAd(): Boolean {
        connectAds.removeAll(connectAds.filter { it.expired() }.also {
            it.forEach { ad ->
//                Log.d("CONNECT_AD", "expired $ad")
            }
        })
        return connectAds.size > 0
    }

    private fun assertConnectAdCount(): Boolean {
        if (totalShow >= AppConfig.totalShowLimit) return false
        if (totalClick >= AppConfig.totalClickLimit) return false
        if (connectShow >= AppConfig.connectShowLimit) return false
        if (connectClick >= AppConfig.connectClickLimit) return false
        return true
    }

    fun preLoadAd() {
//        Log.d("CONNECT_AD", "pre load ad")
        requestConnectAd()
    }

}