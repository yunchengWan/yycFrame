package com.vpn.master.better.hotspot.fast.model

data class City(
    val city_id: Int,
    val city_name: String
)

data class Server(
    val country_name: String,
    val country_code: String,
    val city: List<City>
)

data class Account(
    val ip: String,
    val port: Int,
    val pwd: String,
    val encrypt: String,
    val city_name: String,
    val country_code: String,
    val country_name: String
)

data class ServerInfo(
    val free_server: List<Server>
)