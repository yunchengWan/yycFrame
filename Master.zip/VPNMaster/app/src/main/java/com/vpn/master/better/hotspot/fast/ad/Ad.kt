package com.vpn.master.better.hotspot.fast.ad

import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.InterstitialAd
import com.vpn.master.better.hotspot.fast.helper.AppConfig

interface Ad {
    var createTime: Long

    var priority: Int

    fun expired(): Boolean
}

interface Interstitial : Ad {
    fun show()

    fun clickListener(onClick: () -> Unit)

    fun closeListener(onClose: () -> Unit)

    fun showListener(onShow: () -> Unit)
}

interface Native : Ad {

}

class AdMobInterstitial(private val ad: InterstitialAd) : Interstitial {

    override var createTime: Long = System.currentTimeMillis()
    override var priority: Int = 0

    private var onClick: (() -> Unit)? = null
    private var onClose: (() -> Unit)? = null
    private var onShow: (() -> Unit)? = null

    init {
        ad.adListener = object : AdListener() {
            override fun onAdClicked() {
                onClick?.let { it() }
            }

            override fun onAdClosed() {
                onClose?.let { it() }
            }
        }
    }

    override fun show() {
        onShow?.let { it() }
        ad.show()
    }

    override fun clickListener(onClick: () -> Unit) {
        this.onClick = onClick
    }

    override fun closeListener(onClose: () -> Unit) {
        this.onClose = onClose
    }

    override fun showListener(onShow: () -> Unit) {
        this.onShow = onShow
    }

    override fun expired(): Boolean {
        val time = System.currentTimeMillis() - createTime
        return time >= (AppConfig.expireTime * 1000)
    }
}