package com.vpn.master.better.hotspot.fast.net

import okhttp3.RequestBody
import retrofit2.http.*

interface Server {

    @GET("{url}")
    suspend fun get(@Path(value = "url", encoded = true) path: String, @QueryMap params: Map<String, String>?): String

    @POST("{url}")
    suspend fun post(@Path(value = "url",  encoded = true) path: String, @Body body: RequestBody): String

    @GET
    suspend fun getByFullUrl(@Url url: String, @QueryMap params: Map<String, String>?): String

    @POST
    suspend fun postByFullUrl(@Url url: String, @Body body: RequestBody): String

}