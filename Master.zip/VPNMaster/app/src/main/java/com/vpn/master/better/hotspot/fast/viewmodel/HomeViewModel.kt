package com.vpn.master.better.hotspot.fast.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.shadowsocks.Core
import com.github.shadowsocks.aidl.IShadowsocksService
import com.github.shadowsocks.aidl.ShadowsocksConnection
import com.github.shadowsocks.bg.BaseService
import com.github.shadowsocks.database.Profile
import com.github.shadowsocks.database.ProfileManager
import com.github.shadowsocks.preference.DataStore
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import com.vpn.master.better.hotspot.fast.ad.AdHelper
import com.vpn.master.better.hotspot.fast.helper.AppConfig
import com.vpn.master.better.hotspot.fast.model.Account
import com.vpn.master.better.hotspot.fast.model.Response
import com.vpn.master.better.hotspot.fast.net.HeartRequest
import com.vpn.master.better.hotspot.fast.net.HttpUrl
import com.vpn.master.better.hotspot.fast.net.Request
import com.vpn.master.better.hotspot.fast.utils.AppInfo
import com.vpn.master.better.hotspot.fast.utils.FieldManager.mapToReplace
import com.vpn.master.better.hotspot.fast.utils.Utils
import kotlinx.coroutines.*
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class HomeViewModel : ViewModel(), ShadowsocksConnection.Callback {

    companion object {
        const val SUCCESS = 0x1000
        const val ERROR_CODE_NO_SERVER = 0x1001
        const val ERROR_CODE_PING_FAILED = 0x1002
        const val ERROR_CODE_NO_NETWORK = 0x1003
        const val ERROR_CODE_LIMIT = 0x1004
        const val ERROR_CODE_NEED_UPDATE = 0x1005
    }

    private val vpnConnection = ShadowsocksConnection(true)
    private lateinit var context: Context

    // liveData
    val stateLiveData = MutableLiveData<BaseService.State>()
    val errorCodeLiveDate = MutableLiveData<Int>()

    // other data
    var connectIp: String? = null
    var heartJob: Job? = null

    fun connectService(context: Context) {
        this.context = context
        vpnConnection.connect(context, this)
    }

    fun connectVpn() {

        var result = ERROR_CODE_NO_SERVER
        if (!Utils.networkAvailable()) {
            errorCodeLiveDate.postValue(ERROR_CODE_NO_NETWORK)
            return
        }
        viewModelScope.launch {
            val timeoutResult = withTimeoutOrNull(8 * 1000) {
                launch {
                    // at last 2 second
                    delay(2000)
                }
                launch {
                    // get server
                    result = getServer()
                }
                launch {
                    val connectAdJob = AdHelper.requestConnectAd()
                    connectAdJob?.let {
                        if (it.isActive) it.join()
                    }
                }
                1
            }
            if (timeoutResult == null) {
                //timeout
//                Log.d("CONNECT_AD", "connect 10s timeout")
            }
            if (result == SUCCESS) {
                Core.startService()
            } else {
                errorCodeLiveDate.postValue(result)
            }
        }
    }

    fun disconnectVpn() {
        Core.stopService()
    }

    private suspend fun getServer(): Int = suspendCoroutine { it ->

        viewModelScope.launch(Dispatchers.IO) {
            val accounts: ArrayList<Account> = ArrayList()
            val response = coroutineScope {
                if (AppConfig.selectServer == null) {
                    getAccount()
                } else {
                    getAccountByCountry(AppConfig.selectServer!!.country_code)
                }
            }
            if (response.code == 584032) {
                it.resume(ERROR_CODE_LIMIT)
                return@launch
            }
            if (response.code == 726480) {
                AppConfig.initUpdateInfo()?.join()
                it.resume(ERROR_CODE_NEED_UPDATE)
                return@launch
            }
            response.data?.let {
                if (AppConfig.selectServer == null) {
                    accounts.addAll(it as ArrayList<Account>)
                } else {
                    accounts.add(it as Account)
                }
            }

            if (accounts.isEmpty()) {
                it.resume(ERROR_CODE_NO_SERVER)
            } else {
                val resultList = arrayOfNulls<Int>(accounts.size)
                coroutineScope {
                    repeat(accounts.size) {
                        launch(Dispatchers.IO) {
//                            Log.d(
//                                "PingResult",
//                                "start ping ${accounts[it].ip}"
//                            )
                            resultList[it] = Utils.ping(accounts[it].ip)
//                            Log.d(
//                                "PingResult",
//                                "end ping ${accounts[it].ip}, result = ${resultList[it]}"
//                            )
                        }
                    }
                }

                var minIndex = -1
                var minValue = Int.MAX_VALUE
                for (i in resultList.indices) {
                    if (resultList[i] == null) continue
                    if (resultList[i]!! > -1 && resultList[i]!! < minValue) {
                        minIndex = i
                        minValue = resultList[i]!!
                    }
                }
                if (minIndex > -1) {
//                    Log.d(
//                        "PingResult",
//                        "select ip ${accounts[minIndex].ip}"
//                    )
                    setProfile(accounts[minIndex])
                    it.resume(SUCCESS)
                } else {
//                    Log.d("PingResult", "Ping error")
                    it.resume(ERROR_CODE_PING_FAILED)
                }
            }

        }

    }

    private suspend fun getAccountByCountry(country: String): Response<Account> {
        val params = HashMap<String, String>()
        params["conn_dest".mapToReplace()] = country
        params["conn_mode".mapToReplace()] = "xOktCvXS"
        return Request.get(HttpUrl.GET_ACCOUNT_BY_COUNTRY, params, Account::class.java)
    }

    private suspend fun getAccount(): Response<ArrayList<Account>> {
        return Request.get(
            HttpUrl.GET_ACCOUNTS,
            HashMap(),
            object : TypeToken<ArrayList<Account>>() {}.type
        )
    }

    private fun setProfile(account: Account) {
        val profile = Profile().apply {
            host = account.ip
            remotePort = account.port
            password = account.pwd
            method = account.encrypt
            name = "${account.country_name} - ${account.city_name}"
        }
        connectIp = account.ip
        DataStore.profileId = ProfileManager.createProfile(profile).id
    }

    private fun sendSession() {
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val url = "https://arisa.world/b_sp/"
                val jsonArray = JsonArray()
                jsonArray.add(JsonObject().apply {
                    addProperty("package".mapToReplace(), AppInfo.packageName())
                    addProperty("version".mapToReplace(), AppInfo.versionName())
                    addProperty("device".mapToReplace(), AppInfo.deviceId())
                    addProperty("sys", "android")
                    addProperty("sysv", AppInfo.androidVersion())
                    addProperty("pmid", AppInfo.advertsId())
                    addProperty("lat", if (AppInfo.adLimitTracking()) 1 else 0)
                    addProperty("locale", Locale.getDefault().toString())
                    addProperty("build", AppInfo.buildID())
                    addProperty("model", AppInfo.model())
                    add("fr", JsonArray().apply {
                        add(JsonObject().apply { addProperty("conf", "first") })
                    })
                    addProperty("time", System.currentTimeMillis())
                })
                HeartRequest.postByFullUrl(url, jsonArray)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun startSendHeart() {
        heartJob = GlobalScope.launch(Dispatchers.IO) {
            val params: HashMap<String, String> = HashMap()
            params["package".mapToReplace()] = AppInfo.packageName()
            params["version".mapToReplace()] = AppInfo.versionName()
            params["device".mapToReplace()] = AppInfo.deviceId()
            params["aa"] = "a"
            params["fr"] = "xOktCvXS"
            while (true) {
                try {
                    HeartRequest.getByFullUrl("Https://$connectIp/uiocc", params)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                delay(60 * 1000)
            }
        }
    }

    private fun stopSendHeart() {
        heartJob?.cancel()
        GlobalScope.launch(Dispatchers.IO) {
            val params: HashMap<String, String> = HashMap()
            params["package".mapToReplace()] = AppInfo.packageName()
            params["version".mapToReplace()] = AppInfo.versionName()
            params["device".mapToReplace()] = AppInfo.deviceId()
            params["aa"] = "b"
            params["fr"] = "xOktCvXS"
            HeartRequest.getByFullUrl("Https://$connectIp/uiocc", params)
        }
    }

    override fun stateChanged(
        state: BaseService.State,
        profileName: String?,
        msg: String?
    ) {
        if (state == BaseService.State.Connected) {
            sendSession()
            startSendHeart()
        }
        if (state == BaseService.State.Stopped) {
            stopSendHeart()
        }
        stateLiveData.postValue(state)
    }

    override fun onServiceConnected(service: IShadowsocksService) {
        stateLiveData.postValue(BaseService.State.values()[service.state])
    }


    override fun onServiceDisconnected() {
        stateLiveData.postValue(BaseService.State.Idle)
    }

    override fun onBinderDied() {
        if (this::context.isInitialized) {
            vpnConnection.disconnect(context)
            vpnConnection.connect(context, this)
        }
    }

}