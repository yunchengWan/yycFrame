package com.vpn.master.better.hotspot.fast

import android.animation.ValueAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Window
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.animation.doOnEnd
import com.vpn.master.better.hotspot.fast.helper.ActivityRecord

class LoadingActivity : AppCompatActivity() {

    private lateinit var progress: ProgressBar
    private var firstAnimator: ValueAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.decorView.windowInsetsController?.hide(WindowInsets.Type.systemBars())
        } else {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }

        setContentView(R.layout.activity_loading)
        initView()
        startFirstLoading()
    }

    private fun initView() {
        progress = findViewById(R.id.progress_loading)
    }


    private fun startFirstLoading() {
        firstAnimator = ValueAnimator.ofInt(0, progress.max).apply {
            duration = 2000
            addUpdateListener {
                progress.progress = it.animatedValue as Int
            }
            doOnEnd {
                if (!ActivityRecord.homeLaunched) {
                    startActivity(Intent(this@LoadingActivity, HomeActivity::class.java))
                }
                finish()
            }
            start()
        }
    }

}