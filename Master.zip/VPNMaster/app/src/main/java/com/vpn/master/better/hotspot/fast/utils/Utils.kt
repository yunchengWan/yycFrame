package com.vpn.master.better.hotspot.fast.utils

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.util.TypedValue
import com.vpn.master.better.hotspot.fast.MasterApp
import com.vpn.master.better.hotspot.fast.R
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.resume

class Utils {

    companion object {

        fun readAssert(assertName: String): String? {
            val stream = MasterApp.instance.applicationContext.resources.assets
                .open(assertName)
            return readInputStream(stream)
        }

        suspend fun ping(host: String): Int = suspendCancellableCoroutine {
            try {
                val runtime = Runtime.getRuntime()
                val process = runtime.exec("ping -c 1 -W 2 $host")
                process.waitFor()
                val code = process.exitValue()
                if (code == 0) {
                    val result = readInputStream(process.inputStream)
                    if (result == null) {
                        it.resume(-1)
                    } else {
                        // time=354 ms
                        "time=[0-9]{0,5}".toRegex().find(result)?.let { matchResult ->
                            matchResult.groupValues.let { list ->
                                if (list.isNotEmpty()) {
                                    it.resume(list[0].split("=")[1].toInt())
                                } else {
                                    it.resume(-1)
                                }
                            }
                        } ?: it.resume(-1)
                    }
                } else {
                    it.resume(-1)
                }
            } catch (_: Exception) {
                it.resume(-1)
            }
        }

        private fun readInputStream(inputStream: InputStream): String? {
            try {
                var result: String?

                inputStream.use { input ->
                    ByteArrayOutputStream(input.available()).use { output ->
                        val byteArray = ByteArray(1024)
                        var count: Int
                        while (input.read(byteArray).also { readCount ->
                                count = readCount
                            } != -1) {
                            output.write(byteArray, 0, count)
                        }
                        result = String(output.toByteArray())
                    }

                }
                return result
            } catch (_: Exception) {
                return null
            }
        }

        fun getCountryIcon(countryName: String): Int {
            return when (countryName) {
                "United Kingdom" -> R.drawable.ic_unitedkingdom
                "Germany" -> R.drawable.ic_germany
                "France" -> R.drawable.ic_france
                "Singapore" -> R.drawable.ic_singapore
                "United States" -> R.drawable.ic_unitedstates
                else -> R.drawable.ic_location_unknown
            }
        }

        fun networkAvailable(): Boolean {
            val telephony = MasterApp.instance.applicationContext
                .getSystemService(Context.CONNECTIVITY_SERVICE) ?: return false
            telephony as ConnectivityManager
            return telephony.activeNetwork != null
        }

        fun launchUrl(context: Context, url: String?) {
            if (url.isNullOrEmpty()) return
            try {
                val uri = Uri.parse(url)
                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }

        fun launchGooglePlay(context: Context) {
            try {
                val masterDetail = "detail?id=${AppInfo.packageName()}"
                val playAppIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("market://$masterDetail")
                    `package` = "com.android.vending"
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (playAppIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(playAppIntent)
                } else {
                    launchUrl(context, "https://play.google.com/store/apps/$masterDetail")
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }
}

val Int.dp
    get() = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        this.toFloat(),
        MasterApp.instance.applicationContext.resources.displayMetrics
    ).toInt()

suspend fun <T> withTimeoutNotCancel(
    context: CoroutineContext = EmptyCoroutineContext,
    timeMillis: Long,
    block: suspend CoroutineScope.() -> T
): T? {
    return suspendCancellableCoroutine {
        try {
            val timeout = GlobalScope.launch(context) {
                delay(timeMillis)
                if (!it.isCompleted) {
                    it.resume(null)
                }
            }
            GlobalScope.launch(context) {
                val result = block()
                timeout.cancel()
                if (!it.isCompleted) {
                    it.resume(result)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}