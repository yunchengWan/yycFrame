package com.vpn.master.better.hotspot.fast.net

import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okhttp3.internal.checkOffsetAndCount
import okio.BufferedSink
import java.nio.charset.Charset

abstract class EncryptRequestBody : RequestBody() {
    var encryptKey: String? = null

    companion object {
        /**
         * Returns a new request body that transmits this string. If [contentType] is non-null and lacks
         * a charset, this will use UTF-8.
         */
        @JvmStatic
        @JvmName("create")
        fun String.toEncryptRequestBody(contentType: MediaType? = null): EncryptRequestBody {
            var charset: Charset = Charsets.UTF_8
            var finalContentType: MediaType? = contentType
            if (contentType != null) {
                val resolvedCharset = contentType.charset()
                if (resolvedCharset == null) {
                    charset = Charsets.UTF_8
                    finalContentType = "$contentType; charset=utf-8".toMediaTypeOrNull()
                } else {
                    charset = resolvedCharset
                }
            }
            val bytes = toByteArray(charset)
            return bytes.toEncryptRequestBody(finalContentType, 0, bytes.size)
        }

        /** Returns a new request body that transmits this. */
        @JvmOverloads
        @JvmStatic
        @JvmName("create")
        fun ByteArray.toEncryptRequestBody(
            contentType: MediaType? = null,
            offset: Int = 0,
            byteCount: Int = size
        ): EncryptRequestBody {
            checkOffsetAndCount(size.toLong(), offset.toLong(), byteCount.toLong())
            return object : EncryptRequestBody() {
                override fun contentType() = contentType

                override fun contentLength() = byteCount.toLong()

                override fun writeTo(sink: BufferedSink) {
                    sink.write(this@toEncryptRequestBody, offset, byteCount)
                }
            }
        }
    }

}