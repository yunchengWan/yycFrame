package com.vpn.master.better.hotspot.fast.ad

import android.util.Log
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.google.android.gms.ads.LoadAdError
import com.vpn.master.better.hotspot.fast.MasterApp
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

interface Request {
    suspend fun requestInterstitial(id: String): Interstitial?
}

class AdMobRequest : Request {

    override suspend fun requestInterstitial(id: String): Interstitial?  = suspendCancellableCoroutine {
        InterstitialAd(MasterApp.instance.applicationContext).apply {
            adListener = object : AdListener(){

                override fun onAdFailedToLoad(p0: LoadAdError?) {
//                    Log.d("CONNECT_AD", "onAdFailedToLoad, code = ${p0?.code}")
                    it.resume(null)
                }

                override fun onAdLoaded() {
                    it.resume(AdMobInterstitial(this@apply))
                }
            }
            adUnitId = id
        }.loadAd(
            AdRequest.Builder().build()
        )
    }
}